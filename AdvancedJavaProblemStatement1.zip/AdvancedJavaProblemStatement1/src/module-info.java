module AdvancedJavaProblemStatement1 {
	requires java.sql;
}