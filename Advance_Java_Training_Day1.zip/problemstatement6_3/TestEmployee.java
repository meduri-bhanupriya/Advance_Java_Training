package com.Bhanupriya.problemstatement6_3;

import java.util.Vector;

public class TestEmployee {
	public static void main(String[] args) {
		Vector<EmployeeP_6_3> v = addInput();
		display(v);
	}

	private static Vector<EmployeeP_6_3> addInput() {
		// TODO Auto-generated method stub
		EmployeeP_6_3 e1 = new EmployeeP_6_3(101,"Bhanu","Vijayawada") ;
		EmployeeP_6_3 e2 = new EmployeeP_6_3(102,"Priya","Guntur") ;
		EmployeeP_6_3 e3 = new EmployeeP_6_3(103,"Lalitha","Pune") ;
		Vector<EmployeeP_6_3> v = new Vector<EmployeeP_6_3>();
		v .add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(Vector<EmployeeP_6_3> v) {
		// TODO Auto-generated method stub
		for(EmployeeP_6_3 e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
}
