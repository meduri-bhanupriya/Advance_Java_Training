package com.Bhanupriya.problemstatement3_1;


public abstract class Instrument
{
public abstract void Play();
}