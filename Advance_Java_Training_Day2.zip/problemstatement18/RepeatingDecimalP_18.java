package com.Bhanupriya.problemstatement18;

import java.util.HashMap;
import java.util.Scanner;

public class RepeatingDecimalP_18 {
	public static String solution(int num, int den) {
		StringBuilder ans = new StringBuilder();
		int q = num / den;
		int r = num % den;
		ans.append(q);
		ans.append(".");
		if(r == 0) {
			return ans.toString();
		}else {
			ans.append(" ");
	//String.valueOf(q);
			HashMap<Integer, Integer> map =new HashMap<>();
			while(r!=0) {
				if(map.containsKey(r)) {
					int len = map.get(r);
					ans.insert(len, "(");
					ans.append(")");
					break;
				}else {
					map.put(r, ans.length());
				r *= 10;
				q = r / den;
				r = r % den;
				ans.append(q);
				}
			}
		}
		
		return ans.toString();
		
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the value of num");
		int num = scn.nextInt();
		System.out.println("Enter the value of den");
		int den = scn.nextInt();
		System.out.println(solution(num,den));
	}
	
	
}